# Riley Rudolfo, Colby Crutcher, Ben Foster


# Running this Program


1. Run 'make' to compile the code
2. Run ./diff to run the code
3. To clean: run 'make clean' to remove the diff binary, and it is ready for recompilation


Note: We changed the makefile from sm_30 to sm_86 to run on the server's GPU