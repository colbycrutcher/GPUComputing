Colby Crutcher

Homework 1

CSCD 

# Running this project:

1. Run "make"
2. From here, you should have your hw1 file.
3. Run ./hw1 to run the code. Two files will be created, sortedWord.txt(sorted by alphabetical order), and sortedOccur.txt (Sorted by word frequency).

