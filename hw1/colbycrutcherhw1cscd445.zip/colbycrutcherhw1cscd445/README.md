Colby Crutcher

Homework 1

CSCD 

# Running this project:

1. Run "make"
2. run "make run"
3. run "make clean" to clear up object files.

From here, you should have your hw1 file.


Run ./hw1 to run the code. Two files will be created, sortedAlphabetical.txt(sorted by alphabetical order), and sortedFreq.txt (Sorted by word frequency).

