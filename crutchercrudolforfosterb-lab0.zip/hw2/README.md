# CSCD 445 HW2


Colby Crutcher, Riley Rudolfo, Ben Foster

# Running this file:

1. Run make in the terminal.
2. This makes 'lab0' file, run ./lab0 to execute the program
3. After the program executes, feel free to run make clean to clean up the files, and prepare for recompile